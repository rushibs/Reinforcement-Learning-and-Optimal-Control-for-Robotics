# Project 2 - Q-learning

The decription of the tasks is provided in the Jupyter Notebook " Learning to invert a pendulum.ipynb"

You will need to submit on NYUClasses:
1. A report (pdf only) detailing your answers to all the questions. Please do include plots but do NOT include code.
2. The code used to answer the questions - please provide either one Jupyter Notebook per Part or one runnable python script per part. The provided files must be runnable on Python 3.6 or above.

